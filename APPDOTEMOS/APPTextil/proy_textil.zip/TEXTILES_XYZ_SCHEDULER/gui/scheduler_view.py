# gui/scheduler_view.py (v5.2)
# Módulo para configurar parámetros, ejecutar el balanceo y ver resultados.
# NOVEDAD v5.2: Corregida la importación circular.

import tkinter as tk
from tkinter import ttk, messagebox
from src.data_loader import data_loader
from src.scheduling_engine import calcular_datos_iniciales, balanceo_heuristico_secuencial
from src.gantt_utils import generar_gantt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg

class SchedulerView(ttk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent)
        self.controller = controller

        self.selected_op_id = tk.StringVar()
        self.num_operarios = tk.IntVar(value=5)
        self.tiempo_a_nivelar = tk.IntVar(value=480) # Default 8 horas

        # --- Widgets ---
        btn_home = ttk.Button(self, text="< Volver al Inicio",
                              command=lambda: controller.show_frame("LandingPage"))
        btn_home.pack(pady=10, padx=10, anchor="nw")

        frame_params = ttk.LabelFrame(self, text="Parámetros de Balanceo", padding=(10, 5))
        frame_params.pack(fill='x', padx=10, pady=10)

        ttk.Label(frame_params, text="Seleccionar Orden de Producción:").grid(row=0, column=0, padx=5, pady=5, sticky='w')
        self.combo_op = ttk.Combobox(frame_params, textvariable=self.selected_op_id, state='readonly')
        self.combo_op.grid(row=0, column=1, padx=5, pady=5)
        self.combo_op.bind("<FocusIn>", lambda e: self.actualizar_resumen_ordenes())

        ttk.Button(frame_params, text="Refrescar Lista", command=self.actualizar_resumen_ordenes).grid(row=0, column=2, padx=5)
        ttk.Button(frame_params, text="Eliminar OP Seleccionada", command=self.eliminar_orden_seleccionada).grid(row=0, column=3, padx=5)

        ttk.Label(frame_params, text="Número de Operarios:").grid(row=1, column=0, padx=5, pady=5, sticky='w')
        ttk.Spinbox(frame_params, from_=1, to=100, textvariable=self.num_operarios).grid(row=1, column=1, padx=5, pady=5)

        ttk.Label(frame_params, text="Tiempo a Nivelar por Operario (minutos):").grid(row=2, column=0, padx=5, pady=5, sticky='w')
        ttk.Entry(frame_params, textvariable=self.tiempo_a_nivelar).grid(row=2, column=1, padx=5, pady=5)
        
        btn_balancear = ttk.Button(frame_params, text="Ejecutar Balanceo", command=self.ejecutar_balanceo)
        btn_balancear.grid(row=3, column=0, columnspan=4, pady=10)
        
        self.frame_resultados = ttk.LabelFrame(self, text="Resultados del Balanceo", padding=(10, 5))
        self.frame_resultados.pack(expand=True, fill='both', padx=10, pady=10)
        
        self.actualizar_resumen_ordenes()

    def actualizar_resumen_ordenes(self):
        df_orders_log = data_loader.obtener_orders_log()
        op_ids = df_orders_log['OP_UNIQUE_ID'].unique().tolist() if not df_orders_log.empty else []
        self.combo_op['values'] = op_ids
        if op_ids and not self.selected_op_id.get():
            self.selected_op_id.set(op_ids[0])

    def ejecutar_balanceo(self):
        op_id, num_op, tiempo_nivel = self.selected_op_id.get(), self.num_operarios.get(), self.tiempo_a_nivelar.get()
        if not op_id:
            messagebox.showerror("Error", "Debe seleccionar una Orden de Producción.")
            return

        detalle_orden_df = data_loader.obtener_detalle_orden(op_id)
        if detalle_orden_df is None:
            messagebox.showerror("Error", f"No se pudo cargar el detalle para la OP {op_id}.")
            return
            
        df_datos_iniciales = calcular_datos_iniciales(detalle_orden_df, num_op, tiempo_nivel)
        resultado_balanceo = balanceo_heuristico_secuencial(df_datos_iniciales, num_op, tiempo_nivel)
        
        self.mostrar_resultados(resultado_balanceo)

    def mostrar_resultados(self, resultado_balanceo):
        for widget in self.frame_resultados.winfo_children(): widget.destroy()

        if resultado_balanceo.get("error"):
            ttk.Label(self.frame_resultados, text=f"Error: {resultado_balanceo['error']}", foreground="red").pack()
            return

        kpis = resultado_balanceo.get('kpis', {})
        kpi_frame = ttk.LabelFrame(self.frame_resultados, text="Indicadores Clave (KPIs)")
        kpi_frame.pack(fill='x', padx=5, pady=5)
        
        kpi_text = "\n".join([f"{key}: {value}" for key, value in kpis.items()])
        ttk.Label(kpi_frame, text=kpi_text, justify='left').pack(anchor='w')

        asignaciones = resultado_balanceo.get('asignacion_por_operario', {})
        if asignaciones:
            fig = generar_gantt(asignaciones)
            gantt_frame = ttk.LabelFrame(self.frame_resultados, text="Diagrama de Gantt")
            gantt_frame.pack(expand=True, fill='both', padx=5, pady=5)
            canvas = FigureCanvasTkAgg(fig, master=gantt_frame)
            canvas.draw()
            canvas.get_tk_widget().pack(expand=True, fill='both')
            
    def eliminar_orden_seleccionada(self):
        op_id = self.selected_op_id.get()
        if not op_id:
            messagebox.showwarning("Sin selección", "No hay ninguna orden seleccionada.")
            return

        if messagebox.askyesno("Confirmar Eliminación", f"¿Está seguro de eliminar la OP {op_id}?"):
            data_loader.borrar_orden_por_id(op_id)
            self.actualizar_resumen_ordenes()
            messagebox.showinfo("Éxito", "Orden eliminada correctamente.")

