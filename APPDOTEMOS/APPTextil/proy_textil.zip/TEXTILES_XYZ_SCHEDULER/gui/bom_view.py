# gui/bom_view.py (v5.2)
# Módulo para cargar, visualizar y gestionar el Bill of Materials (BOM).
# NOVEDAD v5.2: Corregida la importación circular.

import tkinter as tk
from tkinter import ttk, filedialog, messagebox

import pandas as pd
from src.data_loader import data_loader

class BomView(ttk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent)
        self.controller = controller

        # --- Widgets ---
        btn_home = ttk.Button(self, text="< Volver al Inicio",
                              command=lambda: controller.show_frame("LandingPage"))
        btn_home.pack(pady=10, padx=10, anchor="nw")

        frame = ttk.LabelFrame(self, text="Carga de Base de Datos de Operaciones (BOM)", padding=(10, 5))
        frame.pack(fill='x', padx=10, pady=10)

        btn_cargar_bom = ttk.Button(frame, text="Cargar Archivo BOM (.csv)", command=self.cargar_bom_csv)
        btn_cargar_bom.pack(pady=5, padx=10, side='left')
        
        btn_exportar_bom = ttk.Button(frame, text="Exportar BOM a CSV Estándar", command=self.exportar_bom_maestro)
        btn_exportar_bom.pack(pady=5, padx=10, side='left')

        bom_frame = ttk.LabelFrame(self, text="Vista Previa del BOM", padding=(10, 5))
        bom_frame.pack(expand=True, fill='both', padx=10, pady=10)
        
        self.tree_bom = ttk.Treeview(bom_frame, show='headings')
        vsb = ttk.Scrollbar(bom_frame, orient="vertical", command=self.tree_bom.yview)
        hsb = ttk.Scrollbar(bom_frame, orient="horizontal", command=self.tree_bom.xview)
        self.tree_bom.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)
        
        vsb.pack(side='right', fill='y')
        hsb.pack(side='bottom', fill='x')
        self.tree_bom.pack(expand=True, fill='both')

        # Cargar BOM al inicio si ya existe en la DB
        self.cargar_bom_existente()

    def cargar_bom_csv(self):
        filepath = filedialog.askopenfilename(
            title="Seleccionar archivo de Base de Datos de Producto",
            filetypes=(("CSV Files", "*.csv"), ("All files", "*.*"))
        )
        if not filepath: return

        # Cargar el CSV SIN normalizar nombres de columnas
        try:
            df = pd.read_csv(filepath, sep=';', decimal=',')
        except Exception as e:
            messagebox.showerror("Error de Carga", f"No se pudo leer el archivo: {e}")
            return

        # Validar columnas requeridas usando los nombres EXACTOS del CSV
        required_cols = ['REFERENCIA', 'DESCRIPCION', 'CONSECUTIVO', 'OPERACION', 'MAQUINA', 'SAM-MINUTOS']
        missing_cols = [col for col in required_cols if col not in df.columns]
        if missing_cols:
            messagebox.showerror("Error de Carga", f"Faltan las siguientes columnas requeridas en el archivo CSV: {', '.join(missing_cols)}")
            return

        # Puedes agregar columnas internas si lo necesitas, pero NO modificar las originales
        df['ID_UNICO'] = range(1, len(df) + 1)  # Ejemplo de columna interna

        self.controller.df_bom_full = df

        # Guardar en la base de datos usando los nombres originales
        save_success, save_message = data_loader.guardar_bom(self.controller.df_bom_full)
        if save_success:
            messagebox.showinfo("Éxito", f"BOM cargado y guardado correctamente.\n{save_message}")
        else:
            messagebox.showwarning("Advertencia de Guardado", save_message)

        self.actualizar_vista_bom()
        self.actualizar_mapa_referencias_controlador()

    def actualizar_vista_bom(self):
        for i in self.tree_bom.get_children(): 
            self.tree_bom.delete(i)
        df = self.controller.df_bom_full
        if df is None or df.empty: 
            return

        # Mostrar exactamente las columnas del CSV, más las internas al final
        columnas_csv = [col for col in ['REFERENCIA', 'DESCRIPCION', 'CONSECUTIVO', 'OPERACION', 'MAQUINA', 'SAM-MINUTOS'] if col in df.columns]
        columnas_extra = [col for col in df.columns if col not in columnas_csv]
        columnas_final = columnas_csv + columnas_extra

        self.tree_bom["columns"] = columnas_final
        for col in columnas_final:
            self.tree_bom.heading(col, text=col)
            self.tree_bom.column(col, width=120, anchor='w')

        for _, row in df.head(100).iterrows():
            self.tree_bom.insert("", "end", values=[row[col] for col in columnas_final])
            
    def actualizar_mapa_referencias_controlador(self):
        df = self.controller.df_bom_full
        if df is not None and not df.empty:
            if 'REFERENCIA' in df.columns and 'DESCRIPCION' in df.columns:
                self.controller.referencia_nombre_map = df.drop_duplicates('REFERENCIA').set_index('REFERENCIA')['DESCRIPCION'].to_dict()
    
    def exportar_bom_maestro(self):
        if self.controller.df_bom_full is None or self.controller.df_bom_full.empty:
            messagebox.showwarning("Advertencia", "No hay datos BOM para exportar.")
            return
        
        ruta_export = filedialog.asksaveasfilename(
            defaultextension=".csv", filetypes=[("CSV files", "*.csv")],
            title="Guardar BOM como CSV estándar"
        )
        if not ruta_export: return
            
        success, message = data_loader.exportar_bom_a_csv(ruta_export)
        if success:
            messagebox.showinfo("Éxito", message)
        else:
            messagebox.showerror("Error", message)

    def cargar_bom_existente(self):
        # Intenta cargar el BOM desde la base de datos al iniciar la vista
        from src.data_loader import data_loader
        df = data_loader.obtener_bom_completo()
        if df is not None and not df.empty:
            self.controller.df_bom_full = df
            self.actualizar_vista_bom()
            self.actualizar_mapa_referencias_controlador()
