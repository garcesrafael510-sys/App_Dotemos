# gui/reports_view.py (v5.2)
# Placeholder para el futuro módulo de informes.
# NOVEDAD v5.2: Corregida la importación circular.

import tkinter as tk
from tkinter import ttk
from gui.theme import FONT_SUBTITULO

class ReportsView(ttk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent)
        self.controller = controller

        btn_home = ttk.Button(self, text="< Volver al Inicio",
                              command=lambda: controller.show_frame("LandingPage"))
        btn_home.pack(pady=10, padx=10, anchor="nw")
        
        lbl_title = ttk.Label(self, 
                              text="Módulo de Informes y KPIs", 
                              font=FONT_SUBTITULO, 
                              anchor="center")
        lbl_title.pack(pady=50)

        lbl_info = ttk.Label(self, 
                             text="Esta sección está en desarrollo.\nAquí se visualizarán los informes detallados y KPIs históricos.",
                             anchor="center",
                             justify="center")
        lbl_info.pack(pady=20)

