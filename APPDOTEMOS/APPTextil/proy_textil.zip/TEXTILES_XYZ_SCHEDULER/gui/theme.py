# gui/theme.py (v5.5)
# Define la paleta de colores y las fuentes para la aplicación.
# NOVEDAD v5.5: Corregido el código de color inválido que causaba el error TclError.

# --- Paleta de Colores ---
COLOR_PRIMARIO = "#444444"      # Gris oscuro para botones principales
COLOR_SECUNDARIO = "#888888"    # Gris medio para acentos
COLOR_BLANCO = "#FFFFFF"        # Blanco puro
COLOR_NEGRO = "#222222"         # Gris casi negro
COLOR_FONDO_CLARO = "#F5F5F5"   # Gris muy claro para fondos
COLOR_FONDO_MEDIO = "#E0E0E0"   # Gris claro para secciones

# --- Definiciones de Fuentes ---
# Se aumentan los tamaños para mejorar la legibilidad
FONT_TITULO = ("Helvetica", 28, "bold")
FONT_SUBTITULO = ("Helvetica", 18, "bold")
FONT_NORMAL = ("Helvetica", 12)
FONT_BOTON_GRANDE = ("Helvetica", 14, "bold") # Letra en negrita para mejor visibilidad

