# gui/orders_view.py (v5.2)
# Módulo para crear, modificar y guardar órdenes de producción.
# NOVEDAD v5.2: Corregida la importación circular.

import tkinter as tk
from tkinter import ttk, messagebox
import pandas as pd
from src.data_loader import data_loader

class OrdersView(ttk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent)
        self.controller = controller
        self.current_order_items = []

        # --- Widgets ---
        btn_home = ttk.Button(self, text="< Volver al Inicio",
                              command=lambda: controller.show_frame("LandingPage"))
        btn_home.pack(pady=10, padx=10, anchor="nw")

        frame_crear = ttk.LabelFrame(self, text="Añadir Producto a la Orden", padding=(10, 5))
        frame_crear.pack(fill='x', padx=10, pady=10)

        ttk.Label(frame_crear, text="Referencia:").grid(row=0, column=0, padx=5, pady=5, sticky='w')
        self.combo_ref = ttk.Combobox(frame_crear, width=30)
        self.combo_ref.grid(row=0, column=1, padx=5, pady=5)
        self.combo_ref.bind("<<ComboboxSelected>>", self.actualizar_nombre_producto)
        self.combo_ref.bind("<KeyRelease>", self.filtrar_combobox)
        self.combo_ref.bind("<FocusIn>", self.actualizar_lista_referencias) # Actualiza al hacer foco

        ttk.Label(frame_crear, text="Nombre Producto:").grid(row=1, column=0, padx=5, pady=5, sticky='w')
        self.nombre_producto_var = tk.StringVar(value="[Seleccione una referencia]")
        ttk.Label(frame_crear, textvariable=self.nombre_producto_var, font=('Arial', 10, 'italic')).grid(row=1, column=1, padx=5, pady=5, sticky='w')

        ttk.Label(frame_crear, text="Cantidad:").grid(row=2, column=0, padx=5, pady=5, sticky='w')
        self.cantidad_var = tk.IntVar()
        ttk.Entry(frame_crear, textvariable=self.cantidad_var, width=12).grid(row=2, column=1, padx=5, pady=5, sticky='w')

        btn_add = ttk.Button(frame_crear, text="Añadir a la Orden", command=self.anadir_item_orden)
        btn_add.grid(row=3, column=0, columnspan=2, pady=10)

        frame_vista = ttk.LabelFrame(self, text="Detalle y Acciones de la Orden Actual", padding=(10, 5))
        frame_vista.pack(expand=True, fill='both', padx=10, pady=10)

        tree_container = ttk.Frame(frame_vista)
        tree_container.pack(side="left", fill="both", expand=True)

        self.tree_orden_actual = ttk.Treeview(tree_container, columns=('Referencia', 'Nombre', 'Cantidad'), show='headings')
        self.tree_orden_actual.heading('Referencia', text='Referencia')
        self.tree_orden_actual.heading('Nombre', text='Nombre Producto')
        self.tree_orden_actual.heading('Cantidad', text='Cantidad')
        
        vsb = ttk.Scrollbar(tree_container, orient="vertical", command=self.tree_orden_actual.yview)
        self.tree_orden_actual.configure(yscrollcommand=vsb.set)
        vsb.pack(side='right', fill='y')
        self.tree_orden_actual.pack(expand=True, fill='both')

        acciones_container = ttk.Frame(frame_vista, padding=(10, 0))
        acciones_container.pack(side="left", fill="y")

        ttk.Button(acciones_container, text="Remover Seleccionado", command=self.remover_item_seleccionado, width=25).pack(pady=5, padx=5)
        ttk.Button(acciones_container, text="Limpiar Orden Actual", command=self.limpiar_orden_actual, width=25).pack(pady=5, padx=5)
        ttk.Separator(acciones_container, orient='horizontal').pack(fill='x', pady=10, padx=5)
        ttk.Button(acciones_container, text="Guardar Orden de Producción", command=self.guardar_orden_produccion, width=25).pack(pady=10, padx=5)

    def actualizar_lista_referencias(self, event=None):
        """Actualiza la lista del combobox con los datos del controlador."""
        self.combo_ref['values'] = list(self.controller.referencia_nombre_map.keys())

    def actualizar_nombre_producto(self, event=None):
        ref = self.combo_ref.get()
        nombre = self.controller.referencia_nombre_map.get(ref, "Descripción no encontrada")
        self.nombre_producto_var.set(nombre)

    def filtrar_combobox(self, event=None):
        value = self.combo_ref.get().upper()
        if value == '':
            self.combo_ref['values'] = list(self.controller.referencia_nombre_map.keys())
        else:
            data = [item for item in self.controller.referencia_nombre_map.keys() if str(item).upper().startswith(value)]
            self.combo_ref['values'] = data

    def anadir_item_orden(self):
        ref = self.combo_ref.get()
        qty = self.cantidad_var.get()
        nombre = self.nombre_producto_var.get()

        if not ref or not qty or qty <= 0:
            messagebox.showwarning("Datos incompletos", "Debe seleccionar una referencia y una cantidad mayor a cero.")
            return
            
        self.current_order_items.append({'REFERENCIA': ref, 'NOMBRE_DISPLAY': nombre, 'CANTIDAD': qty})
        self.tree_orden_actual.insert("", "end", values=(ref, nombre, qty))
        
        self.combo_ref.set('')
        self.cantidad_var.set(0)
        self.nombre_producto_var.set("[Seleccione una referencia]")
        self.combo_ref.focus()

    def remover_item_seleccionado(self):
        selected_items = self.tree_orden_actual.selection()
        if not selected_items:
            messagebox.showwarning("Sin selección", "Por favor, seleccione uno o más ítems para remover.")
            return

        indices_a_remover = sorted([self.tree_orden_actual.index(item) for item in selected_items], reverse=True)
        for index in indices_a_remover: del self.current_order_items[index]
        for item_id in selected_items: self.tree_orden_actual.delete(item_id)

    def limpiar_orden_actual(self, force=False):
        if not self.current_order_items:
            if not force: messagebox.showinfo("Información", "La orden actual ya está vacía.")
            return

        if force or messagebox.askyesno("Confirmar Limpieza", "¿Está seguro de que desea limpiar todos los ítems de la orden actual?"):
            self.current_order_items.clear()
            for i in self.tree_orden_actual.get_children(): self.tree_orden_actual.delete(i)

    def guardar_orden_produccion(self):
        if not self.current_order_items:
            messagebox.showwarning("Orden vacía", "No hay ítems para guardar.")
            return

        op_id = f"OP-{pd.Timestamp.now().strftime('%Y%m%d-%H%M%S')}"
        try:
            items_to_save = [{'REFERENCIA': item['REFERENCIA'], 'CANTIDAD': item['CANTIDAD']} for item in self.current_order_items]
            data_loader.guardar_orden(op_id, items_to_save)
            messagebox.showinfo("Éxito", f"Orden de producción guardada con el ID: {op_id}")
            self.limpiar_orden_actual(force=True)
            self.controller.show_frame("SchedulerView")
        except Exception as e:
            messagebox.showerror("Error", f"No se pudo guardar la orden: {e}")

