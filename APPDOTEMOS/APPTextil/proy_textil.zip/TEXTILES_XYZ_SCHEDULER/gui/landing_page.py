# gui/landing_page.py (v5.4)
# La pantalla de bienvenida con los botones de navegación principales.
# NOVEDAD v5.4: Mejoras visuales. Fondo azul claro, fuentes más grandes y mejor contraste en botones.

import tkinter as tk
from tkinter import ttk
from gui.theme import (
    COLOR_FONDO_MEDIO, COLOR_NEGRO, COLOR_SECUNDARIO, FONT_TITULO, FONT_BOTON_GRANDE, FONT_SUBTITULO, 
    COLOR_PRIMARIO, COLOR_BLANCO, COLOR_FONDO_CLARO
)

__version__ = "5.4"

class LandingPage(ttk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent, padding=(20, 20))
        self.controller = controller

        # --- Estilos Generales ---
        style = ttk.Style()

        # Fondo principal gris claro
        style.configure("LightGray.TFrame", background=COLOR_FONDO_CLARO)
        self.configure(style="LightGray.TFrame")

        # Botones principales en gris oscuro
        style.configure("Menu.TButton", 
            font=FONT_BOTON_GRANDE,
            padding=(20, 15),
            background=COLOR_BLANCO,      # Fondo blanco
            foreground=COLOR_NEGRO)       # Texto negro
        style.map("Menu.TButton",
            background=[('active', COLOR_FONDO_MEDIO)])

        # Etiquetas sobre fondo claro
        style.configure("LightGray.TLabel", background=COLOR_FONDO_CLARO, foreground=COLOR_NEGRO)


        # --- Layout Principal (2 columnas) ---
        self.columnconfigure(0, weight=3)
        self.columnconfigure(1, weight=1)
        self.rowconfigure(0, weight=1)

        # --- Columna Izquierda: Bienvenida e Instrucciones ---
        left_frame = ttk.Frame(self, padding=(10, 20), style="LightGray.TFrame")
        left_frame.grid(row=0, column=0, sticky="nsew", padx=(0, 20))

        lbl_title = ttk.Label(left_frame, text="Bienvenido al Sistema de Programación",
                              font=FONT_TITULO, anchor="w", style="LightGray.TLabel")
        lbl_title.pack(pady=(20, 10), fill='x')

        lbl_subtitle = ttk.Label(left_frame, text="Guía de Inicio Rápido:",
                                 font=FONT_SUBTITULO, anchor="w", style="LightGray.TLabel")
        lbl_subtitle.pack(pady=(30, 15), fill='x')

        instructions_text = (
            "Este software le guiará para optimizar su línea de producción. Siga estos pasos para un uso efectivo:\n\n"
            "1.  **Gestión de BOM:**\n"
            "    Comience aquí. Cargue el archivo CSV con la base de datos de sus productos y operaciones. Verifique que toda la información (tiempos, máquinas, etc.) sea correcta antes de continuar.\n\n"
            "2.  **Órdenes de Producción:**\n"
            "    Una vez cargado el BOM, cree 'paquetes' o lotes de producción. Seleccione las referencias de los productos y especifique las cantidades a fabricar para generar una nueva orden.\n\n"
            "3.  **Balanceo y Programación:**\n"
            "    El corazón del sistema. Seleccione una orden de producción guardada, defina el número de operarios y el tiempo de trabajo. El motor de balanceo asignará las tareas de forma óptima.\n\n"
            "4.  **Informes y KPIs:**\n"
            "    Visualice los resultados del balanceo, incluyendo la eficiencia, la carga de trabajo por operario y un diagrama de Gantt detallado para la programación final."
        )

        # Usar un widget de Texto con el nuevo tamaño de fuente y color de fondo
        text_instructions = tk.Text(left_frame, wrap="word", height=20, borderwidth=0, 
                                     font=("Helvetica", 14), relief="flat", bg=COLOR_FONDO_CLARO)
        text_instructions.insert("1.0", instructions_text)
        
        # Estilo para los títulos de la lista (ajustado al nuevo tamaño de fuente)
        text_instructions.tag_configure("bold", font=("Helvetica", 14, "bold"))
        text_instructions.tag_add("bold", "4.4", "4.21")
        text_instructions.tag_add("bold", "8.4", "8.28")
        text_instructions.tag_add("bold", "12.4", "12.30")
        text_instructions.tag_add("bold", "16.4", "16.22")
        
        text_instructions.config(state="disabled")
        text_instructions.pack(fill='both', expand=True, pady=5)


        # --- Columna Derecha: Botones de Navegación ---
        right_frame = ttk.Frame(self, style="LightGray.TFrame")
        right_frame.grid(row=0, column=1, sticky="ns", padx=(20, 0), pady=(20,0))
        right_frame.columnconfigure(0, weight=1)

        btn_bom = ttk.Button(right_frame, text="1. Gestión de BOM", style="Menu.TButton",
                             command=lambda: controller.show_frame("BomView"))
        btn_bom.grid(row=0, column=0, padx=10, pady=15, sticky="ew")

        btn_orders = ttk.Button(right_frame, text="2. Órdenes de Producción", style="Menu.TButton",
                                command=lambda: controller.show_frame("OrdersView"))
        btn_orders.grid(row=1, column=0, padx=10, pady=15, sticky="ew")

        btn_scheduler = ttk.Button(right_frame, text="3. Balanceo y Programación", style="Menu.TButton",
                                   command=lambda: controller.show_frame("SchedulerView"))
        btn_scheduler.grid(row=2, column=0, padx=10, pady=15, sticky="ew")
        
        btn_reports = ttk.Button(right_frame, text="4. Informes y KPIs", style="Menu.TButton",
                                 command=lambda: controller.show_frame("ReportsView"))
        btn_reports.grid(row=3, column=0, padx=10, pady=15, sticky="ew")

        # --- Footer: Versión y Marca ---
        footer_font = ("Helvetica", 9, "italic")
        
        brand_label = ttk.Label(self, text="OWLS solution", font=footer_font, style="LightGray.TLabel")
        brand_label.place(relx=0.0, rely=1.0, anchor='sw', x=10, y=-5)

        version_label = ttk.Label(self, text=f"Versión {__version__}", font=footer_font, style="LightGray.TLabel")
        version_label.place(relx=1.0, rely=1.0, anchor='se', x=-10, y=-5)

