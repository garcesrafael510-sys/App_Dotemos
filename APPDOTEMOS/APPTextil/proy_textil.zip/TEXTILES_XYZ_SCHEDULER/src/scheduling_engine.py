# scheduling_engine.py (Versión v3.0 - Lógica de Balanceo Heurístico Secuencial)
# Implementa la nueva lógica de balanceo basada en reglas y asignación secuencial.

import pandas as pd
from typing import Dict, Any, List
from src.data_loader import data_loader

def calcular_datos_iniciales(
    orden_detalle_df: pd.DataFrame,
    numero_operarios: int,
    tiempo_a_balancear_min: int
) -> Dict[str, Any]:
    """
    Punto 4: Prepara el DataFrame inicial con los cálculos de producción
    y la tabla base para el balanceo.
    """
    if orden_detalle_df is None or orden_detalle_df.empty:
        return {"error": "El detalle de la orden está vacío."}

    all_items_data = []
    indicadores_produccion = []
    
    # Procesar cada ítem (producto) en la orden de forma secuencial
    for index, row in orden_detalle_df.iterrows():
        referencia = row['REFERENCIA']
        nombre_producto = row.get('NOMBRE_DISPLAY', referencia) # Usar nombre si está disponible

        df_bom = data_loader.obtener_bom_por_referencia(referencia)
        if df_bom is None or df_bom.empty:
            continue

        # --- 1. Cálculos de Producción por Producto ---
        sam_total_producto = df_bom['SAM-MINUTOS'].sum()
        
        if sam_total_producto == 0:
            unidades_por_hora = 0
        else:
            # Unidades por hora para este producto específico
            unidades_por_hora = (numero_operarios * tiempo_a_balancear_min) / sam_total_producto

        unidades_por_dia = unidades_por_hora * 8

        indicadores_produccion.append({
            "Referencia": referencia,
            "SAM Total Producto": f"{sam_total_producto:.2f} min",
            "Unidades por Hora (Estimado)": f"{unidades_por_hora:.2f}",
            "Unidades por Día (Estimado)": f"{unidades_por_dia:.2f}"
        })

        # --- 2. Tabla de Datos a Generar ---
        df_bom['id'] = range(1, len(df_bom) + 1)
        df_bom['codigo_producto'] = referencia
        df_bom['nombre_producto'] = nombre_producto
        df_bom['No secuencia'] = df_bom['CONSECUTIVO']
        df_bom['Sam min operacion'] = df_bom['SAM-MINUTOS']
        df_bom['tiempo_necesario'] = df_bom['SAM-MINUTOS'] * unidades_por_hora
        
        # Seleccionar y reordenar columnas
        item_data = df_bom[[
            'id', 'codigo_producto', 'nombre_producto', 'No secuencia', 
            'OPERACION', 'Sam min operacion', 'tiempo_necesario'
        ]]
        all_items_data.append(item_data)

    if not all_items_data:
        return {"error": "No se encontraron BOMs válidos para los productos de la orden."}

    # Consolidar la tabla de todos los productos
    df_final_balanceo = pd.concat(all_items_data, ignore_index=True)

    # Añadir columnas de operarios dinámicamente
    for i in range(1, numero_operarios + 1):
        df_final_balanceo[f'operario_{i}'] = 0.0

    return {
        "tabla_datos_iniciales": df_final_balanceo,
        "indicadores_produccion": indicadores_produccion,
    }


def balanceo_heuristico_secuencial(
    df_datos_iniciales: pd.DataFrame,
    numero_operarios: int,
    tiempo_limite_min: int
) -> Dict[str, Any]:
    

    cols_needed = ['id', 'codigo_producto', 'nombre_producto', 'No secuencia', 
                  'OPERACION', 'Sam min operacion', 'tiempo_necesario']
    df_asignacion = df_datos_iniciales[cols_needed].copy()

    # Reiniciar columnas de operarios
    for i in range(numero_operarios):
        df_asignacion[f'operario_{i+1}'] = 0.0

    # Inicializar cargas de operarios
    cargas_operarios = {f'operario_{i+1}': 0.0 for i in range(numero_operarios)}
        
    idx_operario_actual = 0
    
    # Iterar sobre cada fila (operación) de la tabla
    for index, row in df_asignacion.iterrows():
        tiempo_op_necesario = row['tiempo_necesario']
        
        # Continuar asignando el tiempo de esta operación hasta que se agote
        while tiempo_op_necesario > 0.01: # Umbral para evitar problemas de punto flotante
            if idx_operario_actual >= numero_operarios:
                # Escenario: Faltan operarios
                return {
                    "error": f"Operarios insuficientes. Se requiere al menos {idx_operario_actual + 1} operarios para asignar la operación '{row['OPERACION']}'.",
                    "df_resultado": df_asignacion,
                    "kpis": None
                }

            nombre_col_operario = f'operario_{idx_operario_actual + 1}'
            tiempo_disponible_operario = tiempo_limite_min - cargas_operarios[nombre_col_operario]

            if tiempo_disponible_operario > 0:
                # Cantidad de tiempo a asignar a este operario
                tiempo_a_asignar = min(tiempo_op_necesario, tiempo_disponible_operario)
                
                # Asignar tiempo en la tabla y actualizar la carga
                df_asignacion.at[index, nombre_col_operario] += tiempo_a_asignar
                cargas_operarios[nombre_col_operario] += tiempo_a_asignar
                
                # Reducir el tiempo de la operación que queda por asignar
                tiempo_op_necesario -= tiempo_a_asignar
            
            # Si el operario actual está lleno, pasar al siguiente
            if abs(cargas_operarios[nombre_col_operario] - tiempo_limite_min) < 0.01:
                idx_operario_actual += 1

    # --- Cálculo de KPIs Internos (Punto 6) ---
    tiempo_total_disponible = numero_operarios * tiempo_limite_min
    tiempo_total_asignado = sum(cargas_operarios.values())
    
    if tiempo_total_disponible > 0:
        porcentaje_asignacion_total = (tiempo_total_asignado / tiempo_total_disponible) * 100
    else:
        porcentaje_asignacion_total = 0

    kpis = {
        "Carga por Operario (min)": {op: round(carga, 2) for op, carga in cargas_operarios.items()},
        "Tiempo Total Asignado (min)": f"{tiempo_total_asignado:.2f}",
        "Tiempo Total Disponible (min)": f"{tiempo_total_disponible:.2f}",
        "% de Asignación de Tiempo Global": f"{porcentaje_asignacion_total:.2f}%"
    }

    # Escenario: Subutilización de operarios
    mensaje_final = "Balanceo completado exitosamente."
    if porcentaje_asignacion_total < 95: # Umbral de ejemplo
        mensaje_final += f" NOTA: El tiempo total asignado ({tiempo_total_asignado:.2f} min) es considerablemente menor al disponible. Se podría reducir el número de operarios."

    return {
        "mensaje": mensaje_final,
        "df_resultado": df_asignacion,
        "kpis": kpis
    }
