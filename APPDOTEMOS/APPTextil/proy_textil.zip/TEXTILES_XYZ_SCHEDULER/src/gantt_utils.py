# src/gantt_utils.py (Versión v2.1 - Generación de Gráfico de Gantt)
import matplotlib.pyplot as plt
import numpy as np
import tempfile
import os

def generar_gantt(asignaciones, nombres_operaciones=None, para_pdf=False):
    """
    Genera un gráfico de Gantt a partir de las asignaciones.
    Si para_pdf=True, guarda la imagen y retorna la ruta.
    Si para_pdf=False, retorna la Figure para usar en Tkinter.
    """
    fig, ax = plt.subplots(figsize=(10, 4))
    operarios = sorted(asignaciones.keys())
    y_labels = [f"Operario {op}" for op in operarios]
    colors = plt.cm.tab20(np.linspace(0, 1, 20))

    for i, operario_id in enumerate(operarios):
        tiempo_inicio = 0
        for j, tarea in enumerate(asignaciones[operario_id]):
            tiempo_op = tarea['minutos_asignados']
            color = colors[j % len(colors)]
            label = tarea.get('descripcion', f"Op {j+1}")
            ax.barh(i, tiempo_op, left=tiempo_inicio, color=color, edgecolor='black', align='center')
            # Etiqueta sobre la barra
            ax.text(tiempo_inicio + tiempo_op/2, i, label, va='center', ha='center', fontsize=8, color='white')
            tiempo_inicio += tiempo_op

    ax.set_yticks(range(len(y_labels)))
    ax.set_yticklabels(y_labels)
    ax.set_xlabel("Tiempo (minutos)")
    ax.set_title("Distribución de Carga de Trabajo por Operario (Diagrama de Gantt)")
    ax.grid(axis='x', linestyle='--', alpha=0.6)
    fig.tight_layout()
    
    if para_pdf:
        # Guarda temporalmente la imagen y retorna la ruta
        temp_dir = tempfile.gettempdir()
        file_path = os.path.join(temp_dir, f"gantt_{os.getpid()}.png")
        fig.savefig(file_path, dpi=300)
        plt.close(fig)
        return file_path
    else:
        # Retorna la figura para incrustar en Tkinter
        return fig
