# main.py (Versión 5.0 - Arquitectura Modular)
# Este es el punto de entrada principal para la aplicación.

import tkinter as tk
from tkinter import ttk
from ttkthemes import ThemedTk
from gui.landing_page import LandingPage
from gui.bom_view import BomView
from gui.orders_view import OrdersView
from gui.scheduler_view import SchedulerView
from gui.reports_view import ReportsView
from gui.theme import FONT_TITULO, FONT_NORMAL

class MainApplication(ThemedTk):
    """
    Controlador principal de la aplicación.
    Gestiona la ventana principal y la navegación entre las diferentes vistas (frames).
    """
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        # Configuración del tema y la ventana principal
        self.set_theme("arc") # Un tema limpio y profesional
        self.title("Textiles XYZ Scheduler v5.0")
        self.geometry("1400x850")

        # Contenedor principal donde se mostrarán las diferentes vistas (páginas)
        container = ttk.Frame(self)
        container.pack(side="top", fill="both", expand=True)
        container.grid_rowconfigure(0, weight=1)
        container.grid_columnconfigure(0, weight=1)

        # Diccionario para mantener una referencia a cada frame/página
        self.frames = {}

        # Crear e inicializar cada una de las páginas de la aplicación
        for F in (LandingPage, BomView, OrdersView, SchedulerView, ReportsView):
            page_name = F.__name__
            frame = F(parent=container, controller=self)
            self.frames[page_name] = frame
            frame.grid(row=0, column=0, sticky="nsew")

        # Mostrar la página de inicio (LandingPage) al arrancar
        self.show_frame("LandingPage")
        
        # --- Estado Compartido de la Aplicación ---
        # Datos que necesitan ser accesibles por diferentes vistas
        self.df_bom_full = None
        self.referencia_nombre_map = {}

    def show_frame(self, page_name):
        """Muestra un frame por su nombre de clase."""
        frame = self.frames[page_name]
        frame.tkraise()

if __name__ == "__main__":
    app = MainApplication()
    app.mainloop()
